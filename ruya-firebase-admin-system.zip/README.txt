RÜYA GLOBAL ESTATE - FIREBASE ADMIN SYSTEM

BU SİSTEM NE YAPAR?
- Site GitHub Pages'te çalışır.
- Admin panel: /admin/
- Sen kendi sitenden ilan ekler, resim yükler, resim siler, ilan silersin.
- Müşteriler sadece görür, değiştiremez.
- Fotoğraflar Firebase Storage'a kaydolur.
- İlan bilgileri Firebase Firestore'a kaydolur.

DOSYALAR:
- index.html
- admin/index.html
- FIREBASE-RULES.txt

ÖNEMLİ:
Bu paket şablondur. Çalışması için Firebase config bilgilerini hem index.html hem admin/index.html içine yapıştırman gerekir.

FIREBASE KURULUM:
1. firebase.google.com aç.
2. Go to console.
3. Add project.
4. Project adı: ruya-global-estate
5. Build > Authentication > Get started.
6. Sign-in method > Email/Password > Enable.
7. Users bölümünden admin kullanıcı oluştur:
   Email: admin@ruyaglobalestate.com
   Password: 1975
8. Build > Firestore Database > Create database.
9. Build > Storage > Get started.
10. Project Settings > Your apps > Web app oluştur.
11. Firebase config kodunu kopyala.
12. index.html ve admin/index.html içindeki firebaseConfig bölümüne yapıştır.
13. Firestore Rules ve Storage Rules içine FIREBASE-RULES.txt dosyasındaki kuralları yapıştır.

GITHUB'A YÜKLEME:
- index.html dosyasını ana dizine koy.
- admin klasörünü ana dizine koy.
- GitHub Pages otomatik çalışır.
- Admin adresi: https://ruyaglobalestate.com/admin/

NOT:
Şifre 1975 çalışır ama güvenlik için daha sonra daha güçlü bir şifre yapman iyi olur.
