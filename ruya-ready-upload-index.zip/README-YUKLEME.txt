RÜYA GLOBAL ESTATE - HAZIR GITHUB YÜKLEME PAKETİ

Bu paketin içinde:
- index.html

Yapılacak:
1. ZIP dosyasını telefonda aç.
2. İçindeki index.html dosyasını GitHub'a yükle.
3. GitHub'da ana dizinde index.html olarak görünmeli.
4. Eski index.html varsa yenisiyle değiştir.

Önemli:
Bu dosya Firebase'e bağlanınca kendi sitenden ilan/resim ekleme-silme yapacak.
Bunun için sonraki adımda Firebase config bilgilerini alıp index.html içine eklememiz gerekiyor.

Admin bilgileri:
E-posta: admin@ruyaglobalestate.com
Şifre: 1975
