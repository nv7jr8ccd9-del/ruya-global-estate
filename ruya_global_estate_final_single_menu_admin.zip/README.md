# RÜYA GLOBAL ESTATE

Admin panel: `/admin`

Netlify setup:
1. Upload this ZIP to Netlify.
2. Open Site configuration > Identity and enable Identity.
3. Enable Git Gateway.
4. Invite your email as admin user.
5. Open `/admin` and edit text, images, phone, WhatsApp, listings.
