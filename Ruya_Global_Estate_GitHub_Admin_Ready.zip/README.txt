RÜYA GLOBAL ESTATE - Düzenlenebilir Netlify Site

Bu paket Netlify Drop için değil, GitHub + Netlify için hazırlanmıştır.

Admin panel:
https://SENIN-SITEN.com/admin/

Netlify'da yapılacaklar:
1) Bu klasörü GitHub'a yükle.
2) Netlify > Add new project > Import from GitHub.
3) Site yayına geçince Netlify > Project configuration > Identity bölümünden Identity'i aç.
4) Git Gateway'i aç.
5) Identity > Invite users bölümünden kendi email adresini davet et.
6) Davet linkinden şifre oluştur.
7) /admin adresine gir ve ilan/resim değiştir.

Bu dosyada Google Analytics kodu zaten var: G-DPTY07BNV1
